# Code and Results: Trigger-Based Variable-Fidelity Co-Simulation Scheduling

## Reproduce all results from scratch
```bash
pip install numpy matplotlib scipy
cd python_code
python main.py              # All main tables + Figs 3-6  (~60s, 10 seeds)
python threshold_sweep.py   # Table 8 / Fig 7
python make_pareto_figure.py
python bound_validation.py  # Table 2  (ground-truth bound check)
```

## Key files
| File | Purpose |
|------|---------|
| power_network.py | IEEE 13-bus simulator, 3 fidelity tiers |
| fidelity_scheduler.py | Trigger scheduler + Lipschitz estimator |
| rl_agent.py | PPO agent (numpy-only) |
| harness.py | Unified episode runner |
| baseline_schedulers.py | SurrogateError + Uncertainty baselines |
| bound_validation.py | Ground-truth bound check (Table 2) |
| experiments.py | Core benchmark runner |

## Data files (data/)
All JSON files back every table in the paper.
Seeds: 0-9. Software: Python 3.12, NumPy 2.4.4, SciPy 1.17.1.
