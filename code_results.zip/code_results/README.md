# Code and Results
## Manuscript
Rigorous Validation of a Trigger-Based Variable-Fidelity Co-Simulation Scheduler
for Reinforcement-Learning-Controlled Power-Electronic Systems
Discover Electronics (Springer Nature)

## Reproduce all results
```bash
pip install numpy matplotlib scipy
cd python_code
python main.py              # Main results tables + Figs 3-6  (~60s)
python threshold_sweep.py   # Threshold sweep table
python make_pareto_figure.py
python bound_validation.py  # Ground-truth bound check (Table 2)
```

## Key files
| File | Purpose |
|------|---------|
| power_network.py | IEEE 13-bus simulator, 3 fidelity levels |
| fidelity_scheduler.py | Trigger scheduler + Lipschitz bound |
| rl_agent.py | PPO agent |
| harness.py | Unified episode runner |
| baseline_schedulers.py | SurrogateError + Uncertainty baselines |
| bound_validation.py | Ground-truth bound validation |
| experiments.py | Core benchmark |

## Software
Python 3.12, NumPy 2.4.4, SciPy 1.17.1, Matplotlib 3.x
Random seeds: 0-9
GitHub: https://github.com/hasib1233333/Trigger-Based-Variable
