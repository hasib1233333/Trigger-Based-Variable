"""
main.py
Entry point — runs all experiments and produces:
  • Console result tables
  • Figures saved to ./figures/
"""

import os
import sys
import time
import numpy as np

# Force UTF-8 output on Windows so Unicode table chars print cleanly
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

# ── Try matplotlib; fall back to ASCII if unavailable ──
try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import matplotlib.gridspec as gridspec
    plt.rcParams.update({
        'font.family': 'serif',
        'font.size': 9,
        'axes.labelsize': 9,
        'axes.titlesize': 9.5,
        'legend.fontsize': 7.5,
        'xtick.labelsize': 8,
        'ytick.labelsize': 8,
        'axes.linewidth': 0.8,
        'lines.linewidth': 1.1,
        'pdf.fonttype': 42,   # embed fonts as Type 42 (editable text in PDF)
        'ps.fonttype': 42,
        'text.usetex': False,  # avoid literal backslash-percent rendering bugs
    })
    PLOT = True
except ImportError:
    PLOT = False

from experiments import run_all_experiments, N_STEPS, SCENARIOS
from power_network import PowerNetwork, N_BUS, SLACK
from fidelity_scheduler import FidelityScheduler, SchedulerConfig
from rl_agent import PPOAgent, build_state


# ─── Table Printer ────────────────────────────────────────────────────────────

def print_table(results: dict):
    STRATS = ['always_high', 'always_low', 'periodic', 'trigger']
    SCENS  = ['light', 'heavy', 'fault']

    print("\n" + "="*90, flush=True)
    print("TABLE 1 — Main Results (mean ± std over 3 seeds)", flush=True)
    print("="*90, flush=True)
    hdr = f"{'Strategy':14s} | {'Scenario':6s} | {'RMSE (low=best)':>15s} | {'VVI':>8s} | {'Speedup':>8s} | {'Miss%':>6s} | {'BoundViol':>9s}"
    print(hdr)
    print("-"*90)

    for scen in SCENS:
        for strat in STRATS:
            r = results[scen][strat]
            rmse = f"{r['rmse_mean']:.4f}+/-{r['rmse_std']:.4f}"
            vvi  = f"{r['vvi_mean']:.5f}"
            spd  = f"{r['speedup']:.2f}x"
            ms   = f"{100*r['miss_rate']:.1f}%"
            bv   = f"{100*r['bound_viol']:.1f}%" if strat == 'trigger' else "  N/A "
            print(f"{strat:14s} | {scen:6s} | {rmse:>15s} | {vvi:>8s} | {spd:>8s} | {ms:>6s} | {bv:>9s}")
        print("-"*90)

    print("\nTABLE 2 — Fidelity Distribution (Trigger strategy only)")
    print(f"{'Scenario':8s} | {'HIGH (2)':>10s} | {'MEDIUM (1)':>12s} | {'LOW (0)':>10s}")
    print("-"*50)
    for scen in SCENS:
        fd = results[scen]['trigger']['fid_dist']
        print(f"{scen:8s} | {100*fd[2]:>9.1f}% | {100*fd[1]:>11.1f}% | {100*fd[0]:>9.1f}%")

    print("\nTABLE 3 — Error Bound Analysis (Trigger strategy only)")
    print(f"{'Scenario':8s} | {'Mean Bound (pu)':>16s} | {'Violations>eps_max':>18s}")
    print("-"*50)
    for scen in SCENS:
        r = results[scen]['trigger']
        print(f"{scen:8s} | {r['bound_mean']:>16.5f} | {100*r['bound_viol']:>17.1f}%")


# ─── Detailed Single-Run Trace ────────────────────────────────────────────────

def run_detailed_trace(scenario: str = 'fault', seed: int = 0):
    """
    Run one detailed trace of our trigger scheduler for visualisation.
    Returns arrays: voltages, fidelity_levels, error_bounds, wall_times.
    """
    from experiments import run_single, SCENARIOS, DT, DEADLINE
    cfg = SCENARIOS[scenario]

    np.random.seed(seed)
    net   = PowerNetwork(load_noise_std=0.003)
    agent = PPOAgent(seed=seed)
    sched = FidelityScheduler(SchedulerConfig(deadline_ms=DEADLINE))

    V   = np.ones(N_BUS)
    cap = np.zeros(2, dtype=int)
    x_high_ref = None

    volt_trace = []
    fid_trace  = []
    bound_trace= []
    wall_trace = []

    for step in range(N_STEPS):
        t = step * DT
        load_s = cfg['load_scale']
        if cfg['fault_step'] is not None and step == cfg['fault_step']:
            load_s *= 1.6

        state_vec = build_state(V, cap, sched.s.error_bound, sched.s.fidelity)
        action, cap, lp, val, probs = agent.act(state_vec)

        fid, bound, trigger = sched.decide(t, V, probs, 0.0, x_high_ref)

        t0 = time.perf_counter()
        V  = net.step(t, cap, fid, load_s, DT)
        w  = (time.perf_counter() - t0) * 1000

        if fid == 2:
            x_high_ref = V.copy()

        sched.log_wall_ms[-1] = w
        if w > DEADLINE:
            sched.deadline_misses += 1

        volt_trace.append(V.copy())
        fid_trace.append(fid)
        bound_trace.append(bound)
        wall_trace.append(w)


        reward = -net.voltage_violation_index()
        done = (step == N_STEPS-1)
        agent.remember(state_vec, action, reward, lp, val, done)
        if (step+1) % 40 == 0 or done:
            agent.update(0.0 if done else val)

    return (np.array(volt_trace), np.array(fid_trace),
            np.array(bound_trace), np.array(wall_trace), sched)


# ─── Plotting ─────────────────────────────────────────────────────────────────

def make_figures(results: dict, trace_data: tuple):
    os.makedirs('figures', exist_ok=True)
    volt_t, fid_t, bound_t, wall_t, sched = trace_data
    steps = np.arange(len(fid_t))
    pq_idx = [i for i in range(N_BUS) if i != SLACK]
    from experiments import DEADLINE

    # ── Figure 1: Detailed Trace (fault scenario) ──
    fig = plt.figure(figsize=(7.0, 7.5))
    gs  = gridspec.GridSpec(4, 1, hspace=0.55)

    ax1 = fig.add_subplot(gs[0])
    for i in pq_idx:
        ax1.plot(steps, volt_t[:, i], lw=0.7, alpha=0.55, color='#1f4e79')
    ax1.axhline(0.95, color='#c0392b', ls='--', lw=0.9, label='ANSI limit (0.95-1.05 pu)')
    ax1.axhline(1.05, color='#c0392b', ls='--', lw=0.9)
    ax1.axvline(50, color='#e67e22', ls=':', lw=1.2, label='Fault event')
    ax1.set_ylabel('Bus voltage (p.u.)')
    ax1.set_title('(a) Bus voltage trajectories - fault scenario', loc='left', fontsize=9)
    ax1.legend(fontsize=7, loc='upper right', framealpha=0.95,
               bbox_to_anchor=(1.0, 0.98))
    ax1.set_ylim(0.75, 1.15)

    ax2 = fig.add_subplot(gs[1])
    colors = {0:'#2980b9', 1:'#f39c12', 2:'#27ae60'}
    labels = {0:'LOW (warm-started FD)', 1:'MEDIUM (Newton-Raphson)', 2:'HIGH (AC + switching)'}
    for lvl in [0, 1, 2]:
        mask = fid_t == lvl
        if mask.any():
            ax2.scatter(steps[mask], np.ones(mask.sum())*lvl,
                       c=colors[lvl], s=10, label=labels[lvl], zorder=3)
    ax2.axvline(50, color='#e67e22', ls=':', lw=1.2)
    ax2.set_ylabel('Fidelity level')
    ax2.set_yticks([0,1,2]); ax2.set_yticklabels(['LOW','MED','HIGH'])
    ax2.legend(fontsize=7, loc='upper right', framealpha=0.95,
               bbox_to_anchor=(1.0, 0.98))
    ax2.set_title('(b) Trigger-scheduled fidelity level', loc='left', fontsize=9)
    ax2.set_ylim(-0.5, 2.5)

    ax3 = fig.add_subplot(gs[2])
    ax3.plot(steps, bound_t, color='#2c3e50', lw=0.9, label='Online bound $\\varepsilon(t)$')
    eps_max_used = sched.cfg.eps_max
    ax3.axhline(eps_max_used, color='#c0392b', ls='--', lw=0.9,
                label=f'$\\varepsilon_{{max}}={eps_max_used:.3f}$')
    ax3.axvline(50, color='#e67e22', ls=':', lw=1.2)
    ax3.fill_between(steps, 0, bound_t, alpha=0.15, color='#2c3e50')
    ax3.set_ylabel('Error bound (p.u.)')
    ax3.set_title('(c) Online provable error bound', loc='left', fontsize=9)
    ax3.legend(fontsize=7, loc='upper right', framealpha=0.95,
               bbox_to_anchor=(1.0, 0.98))
    ax3.set_ylim(bottom=0)

    ax4 = fig.add_subplot(gs[3])
    ax4.plot(steps, wall_t, color='#34495e', lw=0.8, alpha=0.85, label='Step wall time')
    ax4.axhline(DEADLINE, color='#c0392b', ls='--', lw=1.0, label=f'Deadline = {DEADLINE:.1f} ms')
    miss_steps = steps[wall_t > DEADLINE]
    if len(miss_steps):
        ax4.scatter(miss_steps, wall_t[wall_t > DEADLINE],
                   c='#c0392b', s=18, zorder=5, label='Deadline miss')
    ax4.axvline(50, color='#e67e22', ls=':', lw=1.2)
    ax4.set_ylabel('Wall time (ms)')
    ax4.set_xlabel('Control step')
    miss_rate = 100 * sched.deadline_miss_rate()
    ax4.set_title(f"(d) Real-time feasibility (miss rate: {miss_rate:.2f}%)", loc='left', fontsize=9)
    ax4.legend(fontsize=7, loc='upper right', framealpha=0.95,
               bbox_to_anchor=(1.0, 0.98))

    plt.savefig('figures/fig1_detailed_trace.pdf', bbox_inches='tight')
    plt.savefig('figures/fig1_detailed_trace.png', dpi=600, bbox_inches='tight')
    plt.close()
    print("[Saved] figures/fig1_detailed_trace.pdf (+ .png)")



    # ── Figure 2: Strategy Comparison ──
    SCENS  = ['light', 'heavy', 'fault']
    STRATS = ['always_high', 'always_low', 'periodic', 'trigger']
    COLORS = ['#27ae60', '#2980b9', '#f39c12', '#c0392b']
    LABELS = ['Always-HIGH', 'Always-LOW', 'Periodic', 'Trigger (proposed)']

    fig, axes = plt.subplots(1, 3, figsize=(7.0, 2.6))
    metrics   = ['rmse_mean', 'speedup', 'miss_rate']
    ylabels   = ['RMSE (p.u.) (lower better)', 'Speedup (x) (higher better)',
                 'Deadline miss rate (lower better)']
    mtitles   = ['(a) Voltage accuracy', '(b) Compute speedup', '(c) Real-time feasibility']

    for mi, (met, ylab, mtit) in enumerate(zip(metrics, ylabels, mtitles)):
        ax = axes[mi]
        x  = np.arange(len(SCENS))
        w  = 0.19
        for si, (strat, col, lab) in enumerate(zip(STRATS, COLORS, LABELS)):
            vals = [results[sc][strat][met] for sc in SCENS]
            offset = (si - 1.5) * w
            ax.bar(x + offset, vals, w, label=lab, color=col, alpha=0.9,
                   edgecolor='black', linewidth=0.3)
        ax.set_xticks(x); ax.set_xticklabels([s.capitalize() for s in SCENS])
        ax.set_ylabel(ylab, fontsize=8)
        ax.set_title(mtit, loc='left', fontsize=8.5)
        if mi == 1:
            ax.set_yscale('log'); ax.set_ylim(0.5, 100)
        if met == 'miss_rate':
            ax.yaxis.set_major_formatter(
                plt.FuncFormatter(lambda v, _: f'{100*v:.0f}%'))
            max_miss = max(results[sc][s][met] for sc in SCENS for s in STRATS)
            ax.set_ylim(0, max(0.01, max_miss * 1.4))

    # Single shared legend below all panels — avoids any overlap with bars
    handles, lbls = axes[0].get_legend_handles_labels()
    fig.legend(handles, lbls, loc='lower center', ncol=4,
               fontsize=7, framealpha=0.95,
               bbox_to_anchor=(0.5, -0.12), borderaxespad=0.)

    plt.tight_layout()
    plt.savefig('figures/fig2_strategy_comparison.pdf', bbox_inches='tight')
    plt.savefig('figures/fig2_strategy_comparison.png', dpi=600, bbox_inches='tight')
    plt.close()
    print("[Saved] figures/fig2_strategy_comparison.pdf (+ .png)")

    # ── Figure 3: Fidelity Distribution (Trigger only) ──
    fig, ax = plt.subplots(figsize=(4.2, 3.4))   # taller to give room below
    scen_labels = [s.capitalize() for s in SCENS]
    fd_high = [results[s]['trigger']['fid_dist'][2] for s in SCENS]
    fd_med  = [results[s]['trigger']['fid_dist'][1] for s in SCENS]
    fd_low  = [results[s]['trigger']['fid_dist'][0] for s in SCENS]
    x = np.arange(len(SCENS))
    ax.bar(x, fd_high, label='HIGH',   color='#27ae60', alpha=0.9, edgecolor='black', linewidth=0.3)
    ax.bar(x, fd_med,  bottom=fd_high, label='MEDIUM', color='#f39c12', alpha=0.9, edgecolor='black', linewidth=0.3)
    ax.bar(x, fd_low,  bottom=np.array(fd_high)+np.array(fd_med),
           label='LOW', color='#2980b9', alpha=0.9, edgecolor='black', linewidth=0.3)
    ax.set_xticks(x); ax.set_xticklabels(scen_labels)
    ax.set_ylabel('Fraction of control steps')
    ax.set_title('Fidelity-level allocation - trigger scheduler', fontsize=9)
    ax.set_ylim(0, 1.10)
    for i, (h, m, l) in enumerate(zip(fd_high, fd_med, fd_low)):
        ax.text(i, 1.02, f'{100*l:.0f}% LOW', ha='center', fontsize=7)
    # Legend below the plot — completely outside the bar area
    ax.legend(fontsize=7.5,
              loc='upper center',
              bbox_to_anchor=(0.5, -0.14),
              ncol=3,
              framealpha=0.95,
              borderaxespad=0.)
    fig.subplots_adjust(bottom=0.22)
    plt.savefig('figures/fig3_fidelity_distribution.pdf', bbox_inches='tight')
    plt.savefig('figures/fig3_fidelity_distribution.png', dpi=600, bbox_inches='tight')
    plt.close()
    print("[Saved] figures/fig3_fidelity_distribution.pdf (+ .png)")




# ─── Main ─────────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    import json

    print("=" * 65)
    print("Variable-Fidelity Co-Simulation for RL-Controlled Power Systems")
    print("IEEE 13-Bus Feeder | Trigger-Based Scheduling | PPO Agent")
    print("=" * 65)

    t_start = time.time()

    print("\n[Phase 1] Running all experiments ...", flush=True)
    results = run_all_experiments(verbose=True)

    print("\n[Phase 1b] Saving results to results.json ...", flush=True)
    # volt_log / wall_log / fid_log arrays are dropped here (kept only inside
    # the per-run dicts used for in-memory table printing) since they are
    # large and are not needed to reproduce Tables 1-3 or Figures 2-3.
    json_safe = {
        scen: {
            strat: {k: v for k, v in summary.items()}
            for strat, summary in strat_results.items()
        }
        for scen, strat_results in results.items()
    }
    with open('results.json', 'w') as f:
        json.dump(json_safe, f, indent=2)

    print("\n[Phase 2] Printing result tables ...", flush=True)
    print_table(results)

    print("\n[Phase 3] Running detailed trace for visualisation ...", flush=True)
    trace = run_detailed_trace(scenario='fault', seed=0)

    if PLOT:
        print("\n[Phase 4] Generating figures ...", flush=True)
        make_figures(results, trace)
    else:
        print("\n[Phase 4] matplotlib not available — skipping figures", flush=True)

    elapsed = time.time() - t_start
    print(f"\n{'='*65}", flush=True)
    print(f"All done in {elapsed:.1f}s", flush=True)
    print(f"Results saved to: figures/", flush=True)
    print(f"{'='*65}", flush=True)
