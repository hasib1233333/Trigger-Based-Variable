"""
bound_validation.py

Validates the error-bound theorem (Theorem 1) against ground truth, rather
than against the scheduler's own internal trigger bookkeeping.

This script exists because an earlier version of this study reported a
"0% bound violation rate" that was actually measuring how often the
predicted bound crossed eps_max (a property of the trigger logic, true by
construction once the trigger fires) rather than whether the predicted
bound ever fell below the REALISED error between the active low-fidelity
trajectory and the true high-fidelity trajectory it approximates (the
actual theorem claim). Measuring the latter directly surfaced two real
bugs:

  1. An off-by-one timing issue: the bound was being evaluated for elapsed
     time up to (but not including) the control step about to be taken,
     then compared against the realised error AFTER that step. Fixed by
     adding step_dt to the elapsed-time argument in
     FidelityScheduler.decide().

  2. model_gap_M was left at a placeholder value (0.010) that was never
     calibrated against either fidelity model actually used in this study.
     The true value, measured directly below, is closer to 4.6 (p.u./s) --
     roughly 450x larger. eps_max was re-tuned from 0.050 to 0.200 to
     compensate (a much larger M pushes the bound up for any given
     elapsed time, so eps_max must rise correspondingly for the scheduler
     to retain any ability to drop fidelity at all).

Usage:
    python bound_validation.py
"""

import json

import numpy as np

from experiments import DT, N_STEPS, SCENARIOS
from fidelity_scheduler import FidelityScheduler, SchedulerConfig
from power_network import N_BUS, PowerNetwork, dc_power_flow, newton_raphson_pf
from rl_agent import PPOAgent, build_state


def measure_model_gap(n_samples: int = 100) -> dict:
    """
    Directly measure ||f_H(x) - f_L(x)|| / dt at matched states, which is
    the empirical quantity model_gap_M is meant to upper-bound.
    """
    np.random.seed(0)
    net = PowerNetwork(load_noise_std=0.003)
    V = np.ones(N_BUS)
    gaps = []
    for step in range(n_samples):
        t = step * DT
        np.random.seed(step)
        P, Q = net._loads(t, 1.0)
        P_inj = -P
        Q_inj = -Q
        P_inj[0] = Q_inj[0] = 0.0
        V_h, _ = newton_raphson_pf(P_inj, Q_inj, V0=V.copy())
        V_l = dc_power_flow(P_inj, Q_inj, V0=V.copy(), max_iter=2)
        gaps.append(float(np.linalg.norm(V_h - V_l)) / DT)
        V = V_h.copy()
    gaps = np.array(gaps)
    return dict(mean=float(gaps.mean()), median=float(np.median(gaps)),
                p90=float(np.percentile(gaps, 90)), max=float(gaps.max()))


def measure_bound_violations(scenario: str, n_seeds: int, cfg: SchedulerConfig,
                               lipschitz_method: str = "90pct") -> dict:
    """
    Run n_seeds episodes and count, over every LOW-fidelity step, whether
    the realised error ||V_low - V_high_ref|| exceeds the bound the
    scheduler computed for that step. This is ground-truth validation of
    Theorem 1, not a check of the trigger's own internal bookkeeping.
    """
    violation_count = 0
    total_low_steps = 0
    for seed in range(n_seeds):
        np.random.seed(seed)
        scfg = SCENARIOS[scenario]
        net = PowerNetwork(load_noise_std=0.003)
        agent = PPOAgent(seed=seed)
        sched = FidelityScheduler(cfg, lipschitz_method=lipschitz_method)
        V = np.ones(N_BUS)
        cap_state = np.zeros(2, dtype=int)
        x_high_ref = None
        ep_steps = 0
        for step in range(N_STEPS):
            t = step * DT
            load_s = scfg["load_scale"]
            if scfg["fault_step"] is not None and step == scfg["fault_step"]:
                load_s *= 1.6
            tmp_s = build_state(V, cap_state, 0.0, 2)
            _, _, _, _, aprobs = agent.act(tmp_s)
            fid, bound, _ = sched.decide(t, V, aprobs, 0.0, x_high=x_high_ref, step_dt=DT)
            eb = sched.s.error_bound
            state_vec = build_state(V, cap_state, eb, fid)
            action, cap_state, log_prob, value, action_probs = agent.act(state_vec)
            V = net.step(t, cap_state, fid, load_scale=load_s, dt=DT)
            if fid == 2:
                x_high_ref = V.copy()
            elif fid == 0 and x_high_ref is not None:
                actual_err = float(np.linalg.norm(V - x_high_ref))
                if actual_err > bound + 1e-9:
                    violation_count += 1
                total_low_steps += 1
            reward = -net.voltage_violation_index()
            done = step == N_STEPS - 1
            agent.remember(state_vec, action, reward, log_prob, value, done)
            ep_steps += 1
            if ep_steps % 40 == 0 or done:
                lv = float(agent.critic.forward(state_vec)[0]) if not done else 0.0
                agent.update(lv)
                ep_steps = 0
    rate = 100 * violation_count / max(total_low_steps, 1)
    return dict(violations=violation_count, total=total_low_steps, rate=rate)


if __name__ == "__main__":
    print("Measuring empirical model-gap rate ||f_H - f_L|| ...")
    gap = measure_model_gap()
    print(f"  mean={gap['mean']:.3f}  median={gap['median']:.3f}  "
          f"p90={gap['p90']:.3f}  max={gap['max']:.3f} (p.u./s)")

    cfg = SchedulerConfig()  # uses corrected defaults: model_gap_M=4.6, eps_max=0.20
    print(f"\nScheduler config: model_gap_M={cfg.model_gap_M}, eps_max={cfg.eps_max}")

    print("\nValidating bound against ground truth, fault scenario, 10 seeds:")
    results = {"model_gap": gap}
    for method in ["90pct", "95pct", "max"]:
        r = measure_bound_violations("fault", 10, cfg, lipschitz_method=method)
        print(f"  {method:6s}: {r['violations']}/{r['total']} = {r['rate']:.2f}%")
        results[method] = r

    with open("bound_validation.json", "w") as f:
        json.dump(results, f, indent=2)
    print("\nSaved bound_validation.json")
