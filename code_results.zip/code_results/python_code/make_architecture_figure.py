"""
make_architecture_figure.py

Generates Figure 1 (system architecture diagram) showing how the PPO agent,
fidelity scheduler, and power network simulator exchange information within
one control step.

Usage:
    python make_architecture_figure.py
"""

import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch

plt.rcParams.update({
    "font.family": "serif", "font.size": 9.5,
    "pdf.fonttype": 42, "ps.fonttype": 42,
})


def _box(ax, x, y, w, h, title, subtitle, fc):
    b = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.08,rounding_size=0.12",
                        linewidth=1.0, edgecolor="black", facecolor=fc)
    ax.add_patch(b)
    ax.text(x + w / 2, y + h * 0.62, title, ha="center", va="center",
             fontsize=9.5, fontweight="bold")
    ax.text(x + w / 2, y + h * 0.30, subtitle, ha="center", va="center", fontsize=8)


def _arrow(ax, x1, y1, x2, y2, label, lx, ly):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle="-|>", lw=1.1, color="black",
                                 connectionstyle="arc3,rad=0.0", shrinkA=2, shrinkB=2))
    ax.text(lx, ly, label, fontsize=8, ha="center", style="italic")


def make_figure(out_prefix: str = "figures/fig4_architecture"):
    os.makedirs(os.path.dirname(out_prefix) or ".", exist_ok=True)

    fig, ax = plt.subplots(figsize=(6.6, 4.4))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 7)
    ax.axis("off")

    _box(ax, 0.6, 4.6, 3.3, 1.5, "PPO agent", "Capacitor switching policy", "#EEEDFE")
    _box(ax, 6.1, 4.6, 3.3, 1.5, "Fidelity scheduler", "Trigger + error bound", "#FAECE7")
    _box(ax, 3.0, 1.0, 4.0, 1.6, "Power network simulator",
         "LOW: warm-started FD   MEDIUM: AC N-R\nHIGH: AC N-R + LC switching", "#E1F5EE")

    _arrow(ax, 3.9, 5.35, 6.1, 5.35, "action entropy", 5.0, 5.55)
    _arrow(ax, 7.0, 4.6, 6.0, 2.6, "fidelity level", 7.3, 3.6)
    _arrow(ax, 3.6, 2.6, 2.3, 4.6, "bus voltages", 1.9, 3.6)
    _arrow(ax, 6.2, 2.0, 7.8, 4.6, "state, wall time", 7.9, 2.9)

    ax.text(0.3, 6.55, "Control loop (one call per simulation step)",
             fontsize=9.5, style="italic")
    rect = mpatches.FancyBboxPatch((0.15, 0.4), 9.7, 6.35,
                                    boxstyle="round,pad=0.05,rounding_size=0.15",
                                    linewidth=0.8, edgecolor="gray",
                                    facecolor="none", linestyle="--")
    ax.add_patch(rect)

    plt.tight_layout()
    plt.savefig(f"{out_prefix}.pdf", bbox_inches="tight")
    plt.savefig(f"{out_prefix}.png", bbox_inches="tight", dpi=600)
    plt.close()
    print(f"Saved {out_prefix}.pdf (+ .png)")


if __name__ == "__main__":
    make_figure()
