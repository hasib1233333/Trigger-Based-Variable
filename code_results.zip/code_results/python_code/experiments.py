"""
experiments.py — benchmark runner for variable-fidelity co-simulation.

Strategies:  always_high | always_low | periodic | trigger (ours)
Scenarios:   light | heavy | fault
"""

import numpy as np
import time
from typing import List

from power_network import PowerNetwork, N_BUS, SLACK, PQ_IDX
from fidelity_scheduler import FidelityScheduler, SchedulerConfig
from rl_agent import PPOAgent, build_state

SCENARIOS = {
    'light': dict(load_scale=0.70, fault_step=None),
    'heavy': dict(load_scale=1.30, fault_step=None),
    'fault': dict(load_scale=1.00, fault_step=50),
}

N_STEPS  = 120
N_SEEDS  = 10      # increased from 3 in earlier revisions; 10 seeds gives a
                    # 95% CI narrow enough to distinguish strategies whose
                    # point estimates differ by more than a few percent
                    # (see Section 7.2 and the CI columns in Table 3)
DT       = 0.01    # s
DEADLINE = 1.5     # ms -- tightened from 3.0 ms after the cached-Jacobian
                   # MEDIUM tier (Section 8.4) reduced overall step costs;
                   # the previous 3 ms value is no longer tight enough to
                   # produce a non-trivial deadline-miss rate (see fig2c)

PERIOD_SEQ = [2, 2, 1, 1, 0, 0]


def run_single(strategy: str, scenario: str, seed: int,
               ref_voltages: np.ndarray = None) -> dict:
    np.random.seed(seed)
    cfg  = SCENARIOS[scenario]
    net  = PowerNetwork(load_noise_std=0.003)
    agent = PPOAgent(seed=seed)

    sched = FidelityScheduler(SchedulerConfig(deadline_ms=DEADLINE)) \
        if strategy == 'trigger' else None

    V          = np.ones(N_BUS)
    cap_state  = np.zeros(2, dtype=int)
    prev_cap   = np.zeros(2, dtype=int)
    x_high_ref = None
    ep_steps   = 0

    vvi_log:  List[float]      = []
    wall_log: List[float]      = []
    volt_log: List[np.ndarray] = []
    fid_log:  List[int]        = []

    for step in range(N_STEPS):
        t      = step * DT
        load_s = cfg['load_scale']
        if cfg['fault_step'] is not None and step == cfg['fault_step']:
            load_s *= 1.6

        # ── Fidelity decision ──────────────────────────────────────────────
        if strategy == 'always_high':
            fid = 2
        elif strategy == 'always_low':
            fid = 0
        elif strategy == 'periodic':
            fid = PERIOD_SEQ[step % len(PERIOD_SEQ)]
        else:
            tmp_s = build_state(V, cap_state, 0.0, 2)
            _, _, _, _, aprobs = agent.act(tmp_s)
            fid, _, _ = sched.decide(t, V, aprobs, 0.0, x_high=x_high_ref)

        # ── RL action ──────────────────────────────────────────────────────
        eb = sched.s.error_bound if sched else 0.0
        state_vec = build_state(V, cap_state, eb, fid)
        action, cap_state, log_prob, value, action_probs = agent.act(state_vec)

        # ── Step simulation ────────────────────────────────────────────────
        t0 = time.perf_counter()
        V  = net.step(t, cap_state, fid, load_scale=load_s, dt=DT)
        elapsed_ms = (time.perf_counter() - t0) * 1000

        # Update scheduler's wall-time log with actual measurement
        if sched is not None and sched.log_wall_ms:
            sched.log_wall_ms[-1] = elapsed_ms
            if elapsed_ms > DEADLINE:
                sched.deadline_misses += 1

        if fid == 2:
            x_high_ref = V.copy()

        vvi  = net.voltage_violation_index()
        switching_cost = float(np.sum(np.abs(cap_state - prev_cap)))
        prev_cap = cap_state.copy()
        fidelity_cost  = fid / 2.0
        reward = -vvi - 0.05 * switching_cost - 0.005 * fidelity_cost
        done = (step == N_STEPS - 1)

        vvi_log.append(vvi)
        wall_log.append(elapsed_ms)
        volt_log.append(V.copy())
        fid_log.append(fid)

        agent.remember(state_vec, action, reward, log_prob, value, done)
        ep_steps += 1
        if ep_steps % 40 == 0 or done:
            lv = float(agent.critic.forward(state_vec)[0]) if not done else 0.0
            agent.update(lv)
            ep_steps = 0

    # ── Metrics ───────────────────────────────────────────────────────────
    volt_arr = np.array(volt_log)
    wall_arr = np.array(wall_log)
    fid_arr  = np.array(fid_log)

    rmse = 0.0
    if ref_voltages is not None:
        rmse = float(np.sqrt(np.mean(
            (volt_arr[:, PQ_IDX] - ref_voltages[:, PQ_IDX]) ** 2)))

    if sched is not None:
        bv_list = [b > sched.cfg.eps_max
                   for b, f in zip(sched.log_bound, sched.log_fidelity)
                   if f < 2]
        bv   = float(np.mean(bv_list)) if bv_list else 0.0
        eb_m = sched.mean_error_bound()
    else:
        bv   = 0.0
        eb_m = 0.0

    return dict(
        rmse_voltage  = rmse,
        mean_vvi      = float(np.mean(vvi_log)),
        total_wall_ms = float(np.sum(wall_arr)),
        miss_rate     = float(np.mean(wall_arr > DEADLINE)),
        fidelity_dist = {k: float(np.mean(fid_arr == k)) for k in [0,1,2]},
        volt_log      = volt_arr,
        wall_log      = wall_arr,
        fid_log       = list(fid_arr),
        mean_error_bound = eb_m,
        bound_violations = bv,
    )


def run_all_experiments(verbose: bool = True) -> dict:
    STRATEGIES = ['always_high', 'always_low', 'periodic', 'trigger']
    all_results: dict = {}

    for scenario in SCENARIOS:
        if verbose:
            print(f"\n{'='*62}", flush=True)
            print(f"  Scenario: {scenario.upper()}", flush=True)
            print('='*62, flush=True)

        all_results[scenario] = {}

        # ── Reference: always_high ─────────────────────────────────────────
        ref_runs = []
        for seed in range(N_SEEDS):
            if verbose:
                print(f"  [always_high ref] seed={seed} ...", end=' ', flush=True)
            r = run_single('always_high', scenario, seed)
            ref_runs.append(r)
            if verbose:
                print(f"done ({r['total_wall_ms']:.0f} ms)", flush=True)
        ref_volt = np.mean([r['volt_log'] for r in ref_runs], axis=0)

        # ── All strategies ─────────────────────────────────────────────────
        for strat in STRATEGIES:
            runs = []
            for seed in range(N_SEEDS):
                ref = ref_volt if strat != 'always_high' else None
                r = run_single(strat, scenario, seed, ref_voltages=ref)
                runs.append(r)
            if verbose:
                print(f"  [{strat}] done", flush=True)

            ref_wall = float(np.mean([r['total_wall_ms'] for r in ref_runs]))
            our_wall = float(np.mean([r['total_wall_ms'] for r in runs]))
            speedup  = ref_wall / max(our_wall, 1e-3)

            fid_dist = {k: float(np.mean([r['fidelity_dist'][k] for r in runs]))
                        for k in [0, 1, 2]}

            rmse_vals = [r['rmse_voltage'] for r in runs]
            rmse_ci95 = (1.96 * float(np.std(rmse_vals, ddof=1)) / np.sqrt(len(rmse_vals))
                         if len(rmse_vals) > 1 else 0.0)

            summary = dict(
                rmse_mean  = float(np.mean(rmse_vals)),
                rmse_std   = float(np.std(rmse_vals)),
                rmse_ci95  = rmse_ci95,
                vvi_mean   = float(np.mean([r['mean_vvi']          for r in runs])),
                speedup    = speedup,
                miss_rate  = float(np.mean([r['miss_rate']         for r in runs])),
                fid_dist   = fid_dist,
                bound_mean = float(np.mean([r['mean_error_bound']  for r in runs])),
                bound_viol = float(np.mean([r['bound_violations']  for r in runs])),
            )
            all_results[scenario][strat] = summary

            if verbose:
                fd = fid_dist
                print(
                    f"    RMSE={summary['rmse_mean']:.4f}±{summary['rmse_ci95']:.4f} (95% CI)  "
                    f"VVI={summary['vvi_mean']:.5f}  "
                    f"Speedup={summary['speedup']:.2f}x  "
                    f"Miss%={100*summary['miss_rate']:.1f}  "
                    f"Fid(H/M/L)={fd[2]:.2f}/{fd[1]:.2f}/{fd[0]:.2f}",
                    flush=True)

    return all_results
