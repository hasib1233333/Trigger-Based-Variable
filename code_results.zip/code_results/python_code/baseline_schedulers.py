"""
baseline_schedulers.py

Independent baseline fidelity schedulers, distinct in mechanism from
FidelityScheduler (fidelity_scheduler.py), used for the comparison in
Section 7.8. Reviewers reasonably ask "why compare only against your own
baselines (always-high/low, periodic)?" -- this module adds two adaptive
schedulers from outside this paper's own design space:

  1. SurrogateErrorScheduler: the simplest possible adaptive rule. Tracks
     the raw, un-projected mismatch between the current low-fidelity state
     and the last known high-fidelity state, and escalates once it exceeds
     a fixed threshold. No Lipschitz extrapolation, no rate-of-change
     trigger, no RL-entropy signal -- just a direct surrogate-error
     threshold, which is the most common pattern in the adaptive
     surrogate-modelling literature (Peherstorfer et al., 2018) outside
     the power-systems-specific framing of this paper.

  2. UncertaintyScheduler: escalates based on the RL critic's value
     estimate instability (a simple proxy for the agent's own uncertainty
     about the current state), rather than on any property of the power-
     flow trajectory at all. This represents a fundamentally different
     class of trigger signal -- agent-internal rather than physics-based --
     and is a fair, independent point of comparison.

Both are deliberately simple (no tuning effort beyond a single threshold)
to serve as honest baselines rather than straw men.
"""

from dataclasses import dataclass, field
from typing import List, Tuple

import numpy as np


@dataclass
class SurrogateErrorConfig:
    threshold: float = 0.05   # raw mismatch threshold (p.u.) before escalating
    cooldown_steps: int = 2
    hysteresis: int = 2


class SurrogateErrorScheduler:
    """
    Simplest possible adaptive scheduler: escalate to HIGH when the raw
    (un-extrapolated) mismatch between the current LOW-fidelity state and
    the last known HIGH-fidelity state exceeds a fixed threshold; otherwise
    drop to LOW once safe for `hysteresis` consecutive checks. No Lipschitz
    projection of how the error might grow before the next check -- this is
    the threshold scheduler's defining limitation relative to our method,
    and the comparison in Section 7.8 quantifies the cost of omitting it.
    """
    def __init__(self, cfg: SurrogateErrorConfig = None):
        self.cfg = cfg or SurrogateErrorConfig()
        self.fidelity = 2
        self.cooldown = 0
        self.safe_count = 0
        self.log_fidelity: List[int] = []
        self.log_wall_ms: List[float] = []
        self.deadline_misses = 0
        self.total_steps = 0

    def decide(self, t: float, x_now: np.ndarray, x_high: np.ndarray = None) -> int:
        mismatch = float(np.linalg.norm(x_now - x_high)) if x_high is not None else 0.0
        if self.cooldown > 0:
            self.fidelity = 2
            self.cooldown -= 1
        elif mismatch > self.cfg.threshold:
            self.fidelity = 2
            self.cooldown = self.cfg.cooldown_steps
            self.safe_count = 0
        else:
            self.safe_count += 1
            if self.safe_count >= self.cfg.hysteresis and self.fidelity > 0:
                self.fidelity = 0
                self.safe_count = 0
        self.log_fidelity.append(self.fidelity)
        return self.fidelity


@dataclass
class UncertaintyConfig:
    value_std_threshold: float = 0.5   # rolling std of critic value estimate
    window: int = 10
    cooldown_steps: int = 2
    hysteresis: int = 2


class UncertaintyScheduler:
    """
    Escalates based on instability of the RL critic's own value estimate
    (a rolling standard deviation over a short window), rather than any
    measured property of the power-flow trajectory. A high variance in the
    critic's value estimate is interpreted as the agent itself being
    uncertain about the current operating point, independent of whatever
    the power-flow solver's accuracy actually is. Included as a genuinely
    different class of trigger signal (agent-internal vs. physics-based)
    for the comparison in Section 7.8.
    """
    def __init__(self, cfg: UncertaintyConfig = None):
        self.cfg = cfg or UncertaintyConfig()
        self.fidelity = 2
        self.cooldown = 0
        self.safe_count = 0
        self._value_window: List[float] = []
        self.log_fidelity: List[int] = []

    def decide(self, value_estimate: float) -> int:
        self._value_window.append(value_estimate)
        if len(self._value_window) > self.cfg.window:
            self._value_window.pop(0)
        value_std = float(np.std(self._value_window)) if len(self._value_window) >= 3 else 0.0

        if self.cooldown > 0:
            self.fidelity = 2
            self.cooldown -= 1
        elif value_std > self.cfg.value_std_threshold:
            self.fidelity = 2
            self.cooldown = self.cfg.cooldown_steps
            self.safe_count = 0
        else:
            self.safe_count += 1
            if self.safe_count >= self.cfg.hysteresis and self.fidelity > 0:
                self.fidelity = 0
                self.safe_count = 0
        self.log_fidelity.append(self.fidelity)
        return self.fidelity
