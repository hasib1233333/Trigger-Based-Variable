"""
threshold_sweep.py

Runs the accuracy-compute tradeoff sweep reported in the paper (Table 4,
Figure 5). Sweeps the scheduler's trigger thresholds from conservative
(Configuration A) to deliberately extreme (Configurations F, G) and reports
RMSE, compute speedup, and LOW-fidelity usage fraction for each, on the
fault scenario.

Usage:
    python threshold_sweep.py

Produces:
    threshold_sweep.json   -- raw results for all swept configurations
"""

import json
import time

import numpy as np

from experiments import DT, N_SEEDS, N_STEPS, SCENARIOS
from fidelity_scheduler import FidelityScheduler, SchedulerConfig
from power_network import N_BUS, PQ_IDX, PowerNetwork
from rl_agent import PPOAgent, build_state

# ─── Sweep configurations ─────────────────────────────────────────────────────
# A-E trace a smooth, conservative-to-looser tradeoff region.
# F-G are deliberately extreme (hysteresis effectively disabled) to test
# whether the scheduler can be pushed past the periodic baseline's speedup.
SWEEP_CONFIGS = {
    "A": SchedulerConfig(eps_max=0.12, rate_thresh=3.0, entropy_min=0.15,
                          hysteresis=2, cooldown_steps=2),
    "B": SchedulerConfig(eps_max=0.16, rate_thresh=3.5, entropy_min=0.12,
                          hysteresis=1, cooldown_steps=1),
    "C": SchedulerConfig(eps_max=0.20, rate_thresh=4.0, entropy_min=0.10,
                          hysteresis=1, cooldown_steps=1),  # reported config
    "D": SchedulerConfig(eps_max=0.25, rate_thresh=4.5, entropy_min=0.07,
                          hysteresis=1, cooldown_steps=1),
    "E": SchedulerConfig(eps_max=0.30, rate_thresh=5.0, entropy_min=0.05,
                          hysteresis=1, cooldown_steps=0),
    "F": SchedulerConfig(eps_max=0.45, rate_thresh=6.0, entropy_min=0.02,
                          hysteresis=1, cooldown_steps=0),
    "G": SchedulerConfig(eps_max=0.80, rate_thresh=10.0, entropy_min=0.00,
                          hysteresis=1, cooldown_steps=0),
}


def run_single(strategy: str, scenario: str, seed: int,
                sched_cfg: SchedulerConfig, deadline: float,
                ref_voltages: np.ndarray = None) -> dict:
    """Run one episode under a given strategy / scheduler configuration."""
    np.random.seed(seed)
    cfg = SCENARIOS[scenario]
    net = PowerNetwork(load_noise_std=0.003)
    agent = PPOAgent(seed=seed)
    sched = FidelityScheduler(sched_cfg) if strategy == "trigger" else None

    V = np.ones(N_BUS)
    cap_state = np.zeros(2, dtype=int)
    prev_cap = np.zeros(2, dtype=int)
    x_high_ref = None
    ep_steps = 0

    vvi_log, wall_log, volt_log, fid_log = [], [], [], []

    for step in range(N_STEPS):
        t = step * DT
        load_s = cfg["load_scale"]
        if cfg["fault_step"] is not None and step == cfg["fault_step"]:
            load_s *= 1.6

        if strategy == "always_high":
            fid = 2
        elif strategy == "always_low":
            fid = 0
        elif strategy == "periodic":
            fid = [2, 2, 1, 1, 0, 0][step % 6]
        else:  # trigger
            tmp_s = build_state(V, cap_state, 0.0, 2)
            _, _, _, _, aprobs = agent.act(tmp_s)
            fid, _, _ = sched.decide(t, V, aprobs, 0.0, x_high=x_high_ref)

        eb = sched.s.error_bound if sched else 0.0
        state_vec = build_state(V, cap_state, eb, fid)
        action, cap_state, log_prob, value, action_probs = agent.act(state_vec)

        t0 = time.perf_counter()
        V = net.step(t, cap_state, fid, load_scale=load_s, dt=DT)
        elapsed_ms = (time.perf_counter() - t0) * 1000

        if sched is not None and sched.log_wall_ms:
            sched.log_wall_ms[-1] = elapsed_ms
            if elapsed_ms > deadline:
                sched.deadline_misses += 1

        if fid == 2:
            x_high_ref = V.copy()

        vvi = net.voltage_violation_index()
        switching_cost = float(np.sum(np.abs(cap_state - prev_cap)))
        prev_cap = cap_state.copy()
        reward = -vvi - 0.05 * switching_cost - 0.005 * (fid / 2.0)
        done = step == N_STEPS - 1

        vvi_log.append(vvi)
        wall_log.append(elapsed_ms)
        volt_log.append(V.copy())
        fid_log.append(fid)

        agent.remember(state_vec, action, reward, log_prob, value, done)
        ep_steps += 1
        if ep_steps % 40 == 0 or done:
            lv = float(agent.critic.forward(state_vec)[0]) if not done else 0.0
            agent.update(lv)
            ep_steps = 0

    volt_arr = np.array(volt_log)
    wall_arr = np.array(wall_log)
    fid_arr = np.array(fid_log)

    rmse = 0.0
    if ref_voltages is not None:
        rmse = float(np.sqrt(np.mean(
            (volt_arr[:, PQ_IDX] - ref_voltages[:, PQ_IDX]) ** 2)))

    return dict(
        rmse=rmse,
        mean_vvi=float(np.mean(vvi_log)),
        total_wall_ms=float(np.sum(wall_arr)),
        miss_rate=float(np.mean(wall_arr > deadline)),
        fid_dist={k: float(np.mean(fid_arr == k)) for k in [0, 1, 2]},
        volt_log=volt_arr,
    )


def run_sweep(scenario: str = "fault", deadline: float = 3.0,
              n_seeds: int = N_SEEDS, verbose: bool = True) -> dict:
    """Run the full A-G threshold sweep plus periodic/always-low references."""
    ref_runs = [run_single("always_high", scenario, s, None, deadline)
                for s in range(n_seeds)]
    ref_volt = np.mean([r["volt_log"] for r in ref_runs], axis=0)
    ref_wall = np.mean([r["total_wall_ms"] for r in ref_runs])

    results = {}
    for name, cfg in SWEEP_CONFIGS.items():
        runs = [run_single("trigger", scenario, s, cfg, deadline, ref_volt)
                for s in range(n_seeds)]
        rmse = float(np.mean([r["rmse"] for r in runs]))
        wall = float(np.mean([r["total_wall_ms"] for r in runs]))
        speedup = ref_wall / max(wall, 1e-9)
        fd = {k: float(np.mean([r["fid_dist"][k] for r in runs])) for k in [0, 1, 2]}
        results[name] = dict(rmse=rmse, speedup=speedup, fid_dist=fd)
        if verbose:
            print(f"{name:14s} RMSE={rmse:.4f}  speedup={speedup:6.2f}x  "
                  f"LOW={100*fd[0]:5.1f}%  MED={100*fd[1]:5.1f}%  HIGH={100*fd[2]:5.1f}%")

    # Reference baselines for comparison
    for strat in ["periodic", "always_low"]:
        runs = [run_single(strat, scenario, s, None, deadline, ref_volt)
                for s in range(n_seeds)]
        rmse = float(np.mean([r["rmse"] for r in runs]))
        wall = float(np.mean([r["total_wall_ms"] for r in runs]))
        speedup = ref_wall / max(wall, 1e-9)
        results[strat] = dict(rmse=rmse, speedup=speedup)
        if verbose:
            print(f"{strat:14s} RMSE={rmse:.4f}  speedup={speedup:6.2f}x")

    return results


if __name__ == "__main__":
    print("Running threshold sweep (fault scenario, deadline=1.5 ms)...")
    results = run_sweep(scenario="fault", deadline=1.5)
    with open("threshold_sweep.json", "w") as f:
        json.dump(results, f, indent=2)
    print("\nSaved threshold_sweep.json")
