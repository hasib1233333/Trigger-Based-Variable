"""
rl_agent.py
Lightweight PPO agent (numpy + manual backprop) for discrete capacitor control.
No PyTorch/TensorFlow dependency — runs anywhere.

State:  [V_1,...,V_13, cap1, cap2, error_bound, fidelity_level]  → dim=17
Action: discrete in {0,1,2,3} = cap_state ∈ {(0,0),(0,1),(1,0),(1,1)}
Reward: -VVI - 0.05·switching_cost - 0.01·fidelity_cost
"""

import numpy as np

# ─── Tiny MLP (forward + backward in numpy) ──────────────────────────────────

def relu(x):         return np.maximum(0, x)
def relu_grad(x):    return (x > 0).astype(float)
def softmax(x):
    e = np.exp(x - np.max(x))
    return e / e.sum()


class MLP:
    """2-hidden-layer MLP, dim: in_dim → H → H → out_dim."""

    def __init__(self, in_dim: int, out_dim: int, H: int = 64, seed: int = 0):
        rng = np.random.default_rng(seed)
        scale = lambda a, b: np.sqrt(2.0 / a)
        self.W1 = rng.standard_normal((H, in_dim))  * scale(in_dim, H)
        self.b1 = np.zeros(H)
        self.W2 = rng.standard_normal((H, H))       * scale(H, H)
        self.b2 = np.zeros(H)
        self.W3 = rng.standard_normal((out_dim, H)) * scale(H, out_dim)
        self.b3 = np.zeros(out_dim)
        self._cache = {}

    def forward(self, x: np.ndarray) -> np.ndarray:
        z1 = self.W1 @ x + self.b1
        a1 = relu(z1)
        z2 = self.W2 @ a1 + self.b2
        a2 = relu(z2)
        z3 = self.W3 @ a2 + self.b3
        self._cache = dict(x=x, z1=z1, a1=a1, z2=z2, a2=a2, z3=z3)
        return z3

    def backward(self, dout: np.ndarray) -> dict:
        c = self._cache
        da2 = self.W3.T @ dout
        dz2 = da2 * relu_grad(c['z2'])
        da1 = self.W2.T @ dz2
        dz1 = da1 * relu_grad(c['z1'])
        return {
            'W3': np.outer(dout, c['a2']),
            'b3': dout,
            'W2': np.outer(dz2, c['a1']),
            'b2': dz2,
            'W1': np.outer(dz1, c['x']),
            'b1': dz1,
        }

    def param_names(self):
        return ['W1','b1','W2','b2','W3','b3']

    def get_params(self):
        return {k: getattr(self, k) for k in self.param_names()}

    def apply_grad(self, grads: dict, lr: float):
        for k, g in grads.items():
            setattr(self, k, getattr(self, k) + lr * g)


class AdamOptimizer:
    def __init__(self, lr=3e-4, beta1=0.9, beta2=0.999, eps=1e-8):
        self.lr = lr; self.b1 = beta1; self.b2 = beta2; self.eps = eps
        self.m = {}; self.v = {}; self.t = 0

    def step(self, params: dict, grads: dict) -> dict:
        self.t += 1
        out = {}
        for k in grads:
            if k not in self.m:
                self.m[k] = np.zeros_like(grads[k])
                self.v[k] = np.zeros_like(grads[k])
            self.m[k] = self.b1*self.m[k] + (1-self.b1)*grads[k]
            self.v[k] = self.b2*self.v[k] + (1-self.b2)*grads[k]**2
            m_hat = self.m[k] / (1 - self.b1**self.t)
            v_hat = self.v[k] / (1 - self.b2**self.t)
            out[k] = params[k] + self.lr * m_hat / (np.sqrt(v_hat) + self.eps)
        return out


# ─── PPO Agent ────────────────────────────────────────────────────────────────

class PPOAgent:
    """
    Proximal Policy Optimisation with numpy-based actor-critic.
    clip_ratio=0.2, entropy_coef=0.01, value_coef=0.5.
    """
    N_ACTIONS = 4
    STATE_DIM = 17   # 13 voltages + 2 cap states + error_bound + fidelity

    ACTION_MAP = np.array([[0,0],[0,1],[1,0],[1,1]])  # action → cap_state

    def __init__(self, H: int = 64, lr: float = 3e-4, gamma: float = 0.99,
                 lam: float = 0.95, clip: float = 0.2, seed: int = 42):
        self.gamma = gamma
        self.lam   = lam
        self.clip  = clip
        self.entropy_coef = 0.01
        self.value_coef   = 0.5

        self.actor  = MLP(self.STATE_DIM, self.N_ACTIONS, H, seed)
        self.critic = MLP(self.STATE_DIM, 1, H, seed+1)
        self.actor_opt  = AdamOptimizer(lr)
        self.critic_opt = AdamOptimizer(lr)

        # Rollout buffer
        self._states: list  = []
        self._actions: list = []
        self._rewards: list = []
        self._log_probs: list = []
        self._values: list  = []
        self._dones: list   = []

        self.train_returns: list = []

    # ── Inference ──────────────────────────────────────────────────────────

    def act(self, state: np.ndarray) -> tuple:
        """Return (action_int, cap_state, log_prob, value, action_probs)."""
        logits = self.actor.forward(state)
        probs  = softmax(logits)
        action = int(np.random.choice(self.N_ACTIONS, p=probs))
        log_prob = float(np.log(probs[action] + 1e-9))
        value = float(self.critic.forward(state)[0])
        cap_state = self.ACTION_MAP[action]
        return action, cap_state, log_prob, value, probs

    def remember(self, state, action, reward, log_prob, value, done):
        self._states.append(state.copy())
        self._actions.append(action)
        self._rewards.append(reward)
        self._log_probs.append(log_prob)
        self._values.append(value)
        self._dones.append(done)

    # ── GAE Advantage Computation ──────────────────────────────────────────

    def _compute_gae(self, last_value: float) -> tuple:
        rewards = np.array(self._rewards)
        values  = np.array(self._values + [last_value])
        dones   = np.array(self._dones, dtype=float)

        T = len(rewards)
        adv = np.zeros(T)
        gae = 0.0
        for t in reversed(range(T)):
            delta = rewards[t] + self.gamma * values[t+1] * (1-dones[t]) - values[t]
            gae = delta + self.gamma * self.lam * (1-dones[t]) * gae
            adv[t] = gae
        returns = adv + values[:T]
        adv = (adv - adv.mean()) / (adv.std() + 1e-8)
        return adv, returns

    # ── PPO Update (K epochs) ──────────────────────────────────────────────

    def update(self, last_value: float = 0.0, K: int = 4):
        if len(self._states) < 2:
            return

        states   = np.array(self._states)
        actions  = np.array(self._actions)
        old_lps  = np.array(self._log_probs)
        adv, ret = self._compute_gae(last_value)

        ep_return = float(np.sum(self._rewards))
        self.train_returns.append(ep_return)

        for _ in range(K):
            idx = np.random.permutation(len(states))
            for start in range(0, len(states), 32):
                batch = idx[start:start+32]
                for i in batch:
                    s = states[i]; a = int(actions[i])
                    old_lp = old_lps[i]
                    A = adv[i]; R = ret[i]

                    # ── Actor update ──
                    logits = self.actor.forward(s)
                    probs  = softmax(logits)
                    new_lp = np.log(probs[a] + 1e-9)
                    ratio  = np.exp(new_lp - old_lp)

                    p_clip = np.clip(ratio, 1-self.clip, 1+self.clip)
                    p_min  = min(ratio*A, p_clip*A)

                    # Policy gradient
                    dlogits = -probs.copy()
                    dlogits[a] += 1.0           # ∂log_prob/∂logit
                    actor_loss_grad = -p_min * dlogits / (abs(p_min) + 1e-8)

                    # Entropy bonus
                    entropy_grad = -(np.log(probs + 1e-9) + 1.0)
                    actor_loss_grad -= self.entropy_coef * entropy_grad

                    actor_grads = self.actor.backward(actor_loss_grad * 1e-2)
                    new_params = self.actor_opt.step(
                        self.actor.get_params(), actor_grads)
                    for k, v in new_params.items():
                        setattr(self.actor, k, v)

                    # ── Critic update ──
                    v_pred = self.critic.forward(s)
                    v_err  = float(v_pred[0]) - R
                    critic_grads = self.critic.backward(
                        np.array([self.value_coef * 2 * v_err * 1e-2]))
                    new_params = self.critic_opt.step(
                        self.critic.get_params(), critic_grads)
                    for k, v_ in new_params.items():
                        setattr(self.critic, k, v_)

        # Clear buffer
        self._states.clear(); self._actions.clear(); self._rewards.clear()
        self._log_probs.clear(); self._values.clear(); self._dones.clear()


# ─── State Builder ────────────────────────────────────────────────────────────

def build_state(V: np.ndarray, cap_state: np.ndarray,
                error_bound: float, fidelity: int) -> np.ndarray:
    s = np.concatenate([
        V,                                    # 13 voltages
        cap_state.astype(float),             # 2 capacitor states
        [np.clip(error_bound, 0, 0.5)],      # 1 error bound
        [fidelity / 2.0],                    # 1 normalised fidelity
    ])
    return s.astype(np.float32)
