"""
make_pareto_figure.py

Generates Figure 5 (accuracy-compute tradeoff frontier) from the output of
threshold_sweep.py. Run threshold_sweep.py first to produce
threshold_sweep.json, then run this script.

Usage:
    python threshold_sweep.py
    python make_pareto_figure.py
"""

import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.family": "serif", "font.size": 9, "axes.labelsize": 9,
    "axes.titlesize": 9.5, "legend.fontsize": 7.5,
    "xtick.labelsize": 8, "ytick.labelsize": 8, "axes.linewidth": 0.8,
    "pdf.fonttype": 42, "ps.fonttype": 42, "text.usetex": False,
})

SMOOTH_REGION = ["A", "B", "C", "D", "E"]
COLLAPSED_REGION = ["F", "G"]
LABEL_OFFSETS = {
    "A": (-16, -2), "B": (6, 6), "C": (-4, 9), "D": (6, -11), "E": (-16, 7),
}


def make_figure(results: dict, out_prefix: str = "figures/fig5_pareto_tradeoff"):
    os.makedirs(os.path.dirname(out_prefix) or ".", exist_ok=True)

    smooth_pts = [(name, results[name]["rmse"], results[name]["speedup"])
                  for name in SMOOTH_REGION]
    collapsed_pts = [(name, results[name]["rmse"], results[name]["speedup"])
                      for name in COLLAPSED_REGION]
    periodic = (results["periodic"]["rmse"], results["periodic"]["speedup"])
    always_low = (results["always_low"]["rmse"], results["always_low"]["speedup"])
    always_high = (0.0, 1.00)  # reference trajectory: zero error by definition

    fig, ax = plt.subplots(figsize=(4.8, 3.8))

    xs = [p[1] for p in smooth_pts]
    ys = [p[2] for p in smooth_pts]
    ax.plot(xs, ys, "o-", color="#c0392b", lw=1.3, ms=5,
            label="Trigger, tunable region (A-E)", zorder=5)
    for name, rmse, spd in smooth_pts:
        ax.annotate(name, (rmse, spd), textcoords="offset points",
                    xytext=LABEL_OFFSETS.get(name, (6, 4)), fontsize=7.5)

    cx = [p[1] for p in collapsed_pts]
    cy = [p[2] for p in collapsed_pts]
    ax.scatter(cx, cy, marker="x", color="#7f1d1d", s=45,
               label="Trigger, collapsed (F-G)", zorder=5)
    if cx:
        ax.annotate(",".join(p[0] for p in collapsed_pts), (cx[0], cy[0]),
                    textcoords="offset points", xytext=(-28, 2), fontsize=7.5)

    ax.scatter(*periodic, marker="s", color="#f39c12", s=60, label="Periodic",
               zorder=6, edgecolor="black", linewidth=0.4)
    ax.annotate("periodic", periodic, textcoords="offset points",
                xytext=(6, -12), fontsize=7.5)
    ax.scatter(*always_low, marker="^", color="#2980b9", s=60, label="Always-LOW",
               zorder=6, edgecolor="black", linewidth=0.4)
    ax.scatter(*always_high, marker="D", color="#27ae60", s=60, label="Always-HIGH",
               zorder=6, edgecolor="black", linewidth=0.4)

    ax.axvline(periodic[0], color="gray", ls=":", lw=0.7, alpha=0.7)
    ax.axhline(periodic[1], color="gray", ls=":", lw=0.7, alpha=0.7)

    ax.set_xlabel("RMSE (p.u.), fault scenario")
    ax.set_ylabel("Compute speedup (x, log scale)")
    ax.set_yscale("log")
    ax.set_ylim(0.7, 100)
    ax.set_title("Accuracy-compute tradeoff frontier", fontsize=9)
    # Legend outside plot area at bottom to avoid overlap with any data point
    ax.legend(fontsize=7, loc='upper center',
              bbox_to_anchor=(0.5, -0.18), ncol=3,
              framealpha=0.95, borderaxespad=0.)
    ax.set_xlim(-0.003, max(0.058, max(p[1] for p in smooth_pts + collapsed_pts) * 1.1))

    plt.tight_layout()
    plt.subplots_adjust(bottom=0.28)   # make room for legend below
    plt.savefig(f"{out_prefix}.pdf", bbox_inches="tight")
    plt.savefig(f"{out_prefix}.png", bbox_inches="tight", dpi=600)
    plt.close()
    print(f"Saved {out_prefix}.pdf (+ .png)")


if __name__ == "__main__":
    with open("threshold_sweep.json") as f:
        results = json.load(f)
    make_figure(results)
