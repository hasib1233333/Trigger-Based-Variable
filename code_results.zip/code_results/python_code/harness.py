"""
harness.py

Unified single-episode runner used by every study in this revision:
  - LF-correction x scheduler ablation (Section 7.6)
  - trigger-signal ablation (Section 7.7)
  - independent baseline scheduler comparison (Section 7.8)
  - training-time-to-convergence study (Section 7.9)
  - adaptive-iteration LOW-fidelity pilot (Section 8.4)

Consolidating this here (rather than re-deriving run_single in every script,
which is what happened during earlier development and caused several
inconsistencies) keeps every study using exactly the same control loop,
reward, and measurement code as experiments.py / main.py.
"""

import time
from typing import Optional

import numpy as np

from power_network import PowerNetwork, N_BUS, PQ_IDX
from fidelity_scheduler import FidelityScheduler, SchedulerConfig
from rl_agent import PPOAgent, build_state
from experiments import SCENARIOS, N_STEPS, DT


def run_episode(strategy: str, scenario: str, seed: int,
                 sched_cfg: Optional[SchedulerConfig] = None,
                 deadline: float = 3.0,
                 low_fidelity_mode: str = "corrected",
                 low_fidelity_iters: int = 2,
                 adaptive_iters: bool = False,
                 trigger_signals: Optional[set] = None,
                 ref_voltages: Optional[np.ndarray] = None,
                 agent_seed: Optional[int] = None) -> dict:
    """
    Run one episode and return a result dict. This is the single source of
    truth for every experiment in the paper; all per-study scripts call this
    rather than re-implementing the control loop.

    strategy: 'always_high' | 'always_low' | 'periodic' | 'trigger'
    low_fidelity_mode: 'corrected' | 'original' (see PowerNetwork docstring)
    adaptive_iters: if True, the LOW-fidelity solve uses 1 iteration during
                    quiet periods and 3 during/just-after an escalation
                    trigger, instead of a fixed low_fidelity_iters (pilot
                    study, Section 8.4). Only meaningful for strategy='trigger'.
    trigger_signals: subset of {'error_bound','rate','entropy'} the trigger
                    scheduler is allowed to use (ablation, Section 7.7).
                    None means all three (the full scheduler).
    """
    np.random.seed(seed)
    cfg = SCENARIOS[scenario]
    net = PowerNetwork(load_noise_std=0.003,
                        low_fidelity_mode=low_fidelity_mode,
                        low_fidelity_iters=low_fidelity_iters)
    agent = PPOAgent(seed=agent_seed if agent_seed is not None else seed)
    sched = FidelityScheduler(sched_cfg or SchedulerConfig()) \
        if strategy == "trigger" else None
    if sched is not None and trigger_signals is not None:
        sched.enabled_signals = trigger_signals

    V = np.ones(N_BUS)
    cap_state = np.zeros(2, dtype=int)
    prev_cap = np.zeros(2, dtype=int)
    x_high_ref = None
    ep_steps = 0
    last_escalation_step = -999

    vvi_log, wall_log, volt_log, fid_log = [], [], [], []

    for step in range(N_STEPS):
        t = step * DT
        load_s = cfg["load_scale"]
        if cfg["fault_step"] is not None and step == cfg["fault_step"]:
            load_s *= 1.6

        if strategy == "always_high":
            fid = 2
        elif strategy == "always_low":
            fid = 0
        elif strategy == "periodic":
            fid = [2, 2, 1, 1, 0, 0][step % 6]
        else:  # trigger
            tmp_s = build_state(V, cap_state, 0.0, 2)
            _, _, _, _, aprobs = agent.act(tmp_s)
            fid, _, trig_reason = sched.decide(t, V, aprobs, 0.0, x_high=x_high_ref)
            if trig_reason in ("error_bound", "rate_of_change"):
                last_escalation_step = step

        eb = sched.s.error_bound if sched else 0.0
        state_vec = build_state(V, cap_state, eb, fid)
        action, cap_state, log_prob, value, action_probs = agent.act(state_vec)

        lf_iters = None
        if fid == 0 and adaptive_iters:
            # More iterations (more accuracy) shortly after an escalation
            # trigger fired, fewer during sustained quiet periods.
            lf_iters = 3 if (step - last_escalation_step) <= 5 else 1

        t0 = time.perf_counter()
        V = net.step(t, cap_state, fid, load_scale=load_s, dt=DT,
                     low_fidelity_iters=lf_iters)
        elapsed_ms = (time.perf_counter() - t0) * 1000

        if sched is not None and sched.log_wall_ms:
            sched.log_wall_ms[-1] = elapsed_ms
            if elapsed_ms > deadline:
                sched.deadline_misses += 1

        if fid == 2:
            x_high_ref = V.copy()

        vvi = net.voltage_violation_index()
        switching_cost = float(np.sum(np.abs(cap_state - prev_cap)))
        prev_cap = cap_state.copy()
        reward = -vvi - 0.05 * switching_cost - 0.005 * (fid / 2.0)
        done = step == N_STEPS - 1

        vvi_log.append(vvi)
        wall_log.append(elapsed_ms)
        volt_log.append(V.copy())
        fid_log.append(fid)

        agent.remember(state_vec, action, reward, log_prob, value, done)
        ep_steps += 1
        if ep_steps % 40 == 0 or done:
            lv = float(agent.critic.forward(state_vec)[0]) if not done else 0.0
            agent.update(lv)
            ep_steps = 0

    volt_arr = np.array(volt_log)
    wall_arr = np.array(wall_log)
    fid_arr = np.array(fid_log)

    rmse = 0.0
    if ref_voltages is not None:
        rmse = float(np.sqrt(np.mean(
            (volt_arr[:, PQ_IDX] - ref_voltages[:, PQ_IDX]) ** 2)))

    return dict(
        rmse=rmse,
        mean_vvi=float(np.mean(vvi_log)),
        total_wall_ms=float(np.sum(wall_arr)),
        miss_rate=float(np.mean(wall_arr > deadline)),
        fid_dist={k: float(np.mean(fid_arr == k)) for k in [0, 1, 2]},
        volt_log=volt_arr,
        train_returns=list(agent.train_returns),
    )


def run_strategy(strategy: str, scenario: str, n_seeds: int,
                  sched_cfg: Optional[SchedulerConfig] = None,
                  deadline: float = 3.0,
                  low_fidelity_mode: str = "corrected",
                  low_fidelity_iters: int = 2,
                  adaptive_iters: bool = False,
                  trigger_signals: Optional[set] = None,
                  ref_volt: Optional[np.ndarray] = None) -> dict:
    """Run n_seeds episodes of one strategy and aggregate. Returns mean/std/CI."""
    runs = [run_episode(strategy, scenario, s, sched_cfg, deadline,
                          low_fidelity_mode, low_fidelity_iters,
                          adaptive_iters, trigger_signals, ref_volt)
            for s in range(n_seeds)]
    rmse_vals = np.array([r["rmse"] for r in runs])
    wall_vals = np.array([r["total_wall_ms"] for r in runs])
    miss_vals = np.array([r["miss_rate"] for r in runs])

    # 95% CI via normal approximation (n=10-20 here; small-sample t-interval
    # would be marginally wider but the normal approx is standard practice
    # for this sample size and is reported as such in the paper).
    def ci95(x):
        if len(x) < 2:
            return 0.0
        return 1.96 * np.std(x, ddof=1) / np.sqrt(len(x))

    return dict(
        rmse_mean=float(rmse_vals.mean()), rmse_std=float(rmse_vals.std(ddof=1)) if len(rmse_vals) > 1 else 0.0,
        rmse_ci95=float(ci95(rmse_vals)),
        wall_mean=float(wall_vals.mean()),
        miss_mean=float(miss_vals.mean()),
        fid_dist={k: float(np.mean([r["fid_dist"][k] for r in runs])) for k in [0, 1, 2]},
        n_seeds=n_seeds,
        runs=runs,
    )
